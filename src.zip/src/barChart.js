
import React from "react";
import { scaleLinear, scaleBand, max, map } from "d3";

function BarChart(props) {
    console.log("plotting barChart");
    const { offsetX, offsetY, data, height, width, selectedCountry, setSelectedCountry } = props;

    
    // --Define a scale for the x-axis -- //
    const xScale = scaleBand().range([0, width]).domain(map(data, d => d.country));
    // -- Define a scale for the y-axis -- //
    const yScale = scaleLinear().range([height/2, 0]).domain([0, max(data, d=>d.happiness_score)]).nice();
    // -- change color with mouse event -- //
    const getColor = (selectedCountry, d) => {
        if (selectedCountry === d.country){
            return "red";
        } else {
            return "#99d594";
        }
    }
    // -- define mouseOver events -- //
    const mouseEnter = (d, event) => {
        setSelectedCountry(d.country);
    }
    const mouseOut = (event) => {
        setSelectedCountry(null);
    }

    console.log("plotting barChart2");
    console.log(offsetX);
    console.log(offsetY);
    console.log(width);
    console.log(height);

    return <g transform={`translate(${offsetX}, ${offsetY})`} >
    <text style={{ textAnchor:'countries', fontSize:'15px'}} transform={`translate(${width/3}, 0)`}>
            {"happiness level"}
    </text>
    <line x1={0} x2={width} y1={height/2} y2={height/2} stroke="black" />
    <line y2={height/2} stroke='black'/>
    {yScale.ticks(5).map(tickValue => 
        <g key={tickValue} transform={`translate(-10, ${yScale(tickValue)})`}>
            <line x2={10} stroke='black' />
            <text style={{ textAnchor:'end', fontSize:'10px' }} >
                {tickValue}
            </text>
            </g> )}

    {data.map(d=>{
            return (
            <rect key={d.country} x={xScale(d.country)} y={yScale(d.happiness_score)} 
            height={yScale(d.happiness_score)} width={xScale.bandwidth()} fill={getColor(selectedCountry, d)} stroke={"black"}
            onMouseEnter={(event) => mouseEnter(d, event)} onMouseOut={(event)=>mouseOut(event)}></rect>
            )
            })}
</g>


/*
return <>

</>
*/
}

export {BarChart};